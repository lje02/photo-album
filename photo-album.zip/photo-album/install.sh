#!/usr/bin/env bash
# ============================================================
#  📷 Photo Album — 一键安装脚本
#  用法：bash install.sh [--dev | --build | --preview]
#  默认行为：构建生产包 + 启动预览服务器（端口 3000）
# ============================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}▶ $*${RESET}"; }
success() { echo -e "${GREEN}✔ $*${RESET}"; }
warn()    { echo -e "${YELLOW}⚠ $*${RESET}"; }
error()   { echo -e "${RED}✖ $*${RESET}" >&2; exit 1; }

MODE="${1:-build}"

echo ""
echo -e "${BOLD}  📷 Photo Album 安装程序${RESET}"
echo -e "  ─────────────────────────"
echo ""

# ── 检查 Node.js ──
if ! command -v node &>/dev/null; then
  error "未找到 Node.js。请先安装 Node.js 18+：https://nodejs.org"
fi

NODE_VER=$(node -e "process.exit(parseInt(process.versions.node.split('.')[0]) < 18 ? 1 : 0)" 2>/dev/null && echo "ok" || echo "old")
if [ "$NODE_VER" = "old" ]; then
  error "Node.js 版本过低（需要 18+），当前版本：$(node -v)"
fi
success "Node.js $(node -v) ✓"

# ── 检查 npm ──
if ! command -v npm &>/dev/null; then
  error "未找到 npm，请重新安装 Node.js"
fi
success "npm $(npm -v) ✓"

# ── 安装依赖 ──
info "正在安装依赖包..."
npm install --prefer-offline --no-audit --no-fund 2>&1 | tail -3
success "依赖安装完成"

# ── 根据模式执行 ──
case "$MODE" in
  --dev|-d)
    info "启动开发服务器（热重载）..."
    echo ""
    echo -e "  ${GREEN}前台地址：${BOLD}http://localhost:5173${RESET}"
    echo -e "  ${GREEN}后台入口：${BOLD}http://localhost:5173/#admin${RESET}"
    echo -e "  ${YELLOW}默认密码：admin123${RESET}"
    echo ""
    npm run dev
    ;;

  --build|-b)
    info "构建生产包..."
    npm run build
    success "构建完成，产物位于 ./dist"
    echo ""
    echo -e "  ${CYAN}可将 dist/ 目录部署到任意静态托管服务：${RESET}"
    echo -e "  • Nginx / Caddy / Apache"
    echo -e "  • Vercel / Netlify / Cloudflare Pages"
    echo -e "  • GitHub Pages"
    echo ""
    ;;

  --preview|-p)
    info "构建并启动预览服务器..."
    npm run build
    success "构建完成"
    echo ""
    echo -e "  ${GREEN}预览地址：${BOLD}http://localhost:3000${RESET}"
    echo -e "  ${GREEN}后台入口：${BOLD}http://localhost:3000/#admin${RESET}"
    echo -e "  ${YELLOW}默认密码：admin123${RESET}"
    echo ""
    npm run serve
    ;;

  *)
    # 默认：build + preview
    info "构建生产包..."
    npm run build
    success "构建完成"
    echo ""
    echo -e "  ${GREEN}本地预览地址：${BOLD}http://localhost:3000${RESET}"
    echo -e "  ${GREEN}后台管理入口：${BOLD}http://localhost:3000/#admin${RESET}"
    echo -e "  ${YELLOW}默认登录密码：${BOLD}admin123${RESET}（可在后台设置中修改）"
    echo ""
    npm run serve
    ;;
esac
