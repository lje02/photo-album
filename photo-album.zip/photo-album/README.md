# 📷 Photo Album

一个简洁优雅的个人相册展示站，基于 React + Vite 构建，支持自托管部署。

## ✨ 功能特性

- 📂 相册分类管理（旅行、城市、自然等）
- 🏷️ 标签系统 + 实时搜索
- 📱 移动端自适应布局
- 🔒 密码保护的后台管理（URL Hash 隐藏入口）
- 💾 数据持久化（localStorage，无需数据库）
- ⚡ Vite 构建，性能极佳

---

## 🚀 一键安装

### 方式一：克隆仓库后运行脚本

```bash
git clone https://github.com/YOUR_USERNAME/photo-album.git
cd photo-album
bash install.sh
```

### 方式二：直接拉取脚本运行（需已克隆）

```bash
# 开发模式（热重载，端口 5173）
bash install.sh --dev

# 仅构建生产包（输出到 dist/）
bash install.sh --build

# 构建 + 本地预览（端口 3000）
bash install.sh --preview
```

---

## 🛠️ 手动安装

```bash
npm install
npm run dev      # 开发模式
npm run build    # 生产构建
npm run serve    # 预览构建结果（端口 3000）
```

---

## 🔑 后台管理

在浏览器地址栏 URL 末尾添加 `#admin` 即可进入后台登录页。

- **默认密码**：`admin123`
- 可在后台「系统设置」中修改密码和站点标题

---

## 🌐 部署到生产

执行 `npm run build` 后，将 `dist/` 目录部署到任意静态托管服务：

### Nginx 示例

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/photo-album/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    gzip on;
    gzip_types text/plain text/css application/javascript;
}
```

### Caddy 示例

```caddy
your-domain.com {
    root * /var/www/photo-album/dist
    file_server
    try_files {path} /index.html
}
```

### 零配置平台

| 平台 | 操作 |
|------|------|
| **Vercel** | `npx vercel` 或连接 GitHub 仓库自动部署 |
| **Netlify** | 拖拽 `dist/` 目录到 Netlify Drop |
| **Cloudflare Pages** | 连接仓库，构建命令 `npm run build`，输出目录 `dist` |
| **GitHub Pages** | 见下方说明 |

### GitHub Pages 部署

1. 修改 `vite.config.js`，添加 `base` 配置：
   ```js
   export default defineConfig({
     base: '/photo-album/',  // 替换为你的仓库名
     // ...
   })
   ```
2. 安装 gh-pages：`npm install -D gh-pages`
3. 在 `package.json` 添加脚本：
   ```json
   "deploy": "npm run build && gh-pages -d dist"
   ```
4. 执行：`npm run deploy`

---

## 📁 项目结构

```
photo-album/
├── src/
│   ├── App.jsx       # 主应用组件
│   └── main.jsx      # 入口文件
├── index.html
├── vite.config.js
├── package.json
├── install.sh        # 一键安装脚本
└── README.md
```

---

## 🔧 环境要求

- Node.js **18+**
- npm **9+**

---

## 📄 License

MIT
